....................................................................................
-Titulo		Perdidinhos e Pacatos - The Adventure
-Versao		1.00
-Ferramenta	SFML
-Game Type	Freeware

-Autores:
	- Ana Ellen Deodato Pereira da Silva
	- Lucas Maciel Balieiro
	- Vinicius Goncalves Perillo
....................................................................................

= Como Iniciar =

Certifique-se de extrair o arquivo .zip
Execute PerdidinhosePacatos.exe


= Nota Importante =
This program contains free software licensed under a number of licenses,
including the GNU Lesser Public License v2.1. 
A complete list of software is available at:https://www.sfml-dev.org/license.php


....................................................................................

= Comandos =

Escape		Fecha aplicacao
A e D		Movimento
Enter		Confirma texto
Espace		Interage com objetos
W			Abre portas


-Completar tarefas -
Teclado para escrever as palavras, Enter para confirmar

....................................................................................

=Sumario=

Peridinhos e Pacatos simula o dia a dia de um estudante
universitario, tendo que fazer tarefas diarias para 
manter sua casa organizada.

O jogo se baseia em um sistema de recordes de tempo, voce deve 
completar todas as tarefas no menor tempo que conseguir.

Para realizar cada tarefa interaja com o objeto indicado pela 
caixa de texto inferior e transcreva a palavra imposta


....................................................................................

= Recursos Usados =

Sound Effects
https://freesound.org/

Font
https://www.1001fonts.com/

Music

	Hari
	https://soundcloud.com/master-jo-official/8-bit-hari

	Moe moe garden in the brain
	https://www.youtube.com/watch?v=ESSZeYHVVtk

	Memo cute, Chiptune
	https://soundcloud.com/user-64658984-774312008/memo-cute-8-bit-chiptune

....................................................................................

= Contatos =
Ana Ellen Deodato	anaellen.uba@gmail.com
Lucas Balieiro		lucas.macbali@gmail.com
Vinicius Perillo	vinicius.perillo25@gmail.com